# omegaseed.io auf DigitalOcean bringen

Droplet mit nginx, Deployment über SSH. Rechnen Sie mit 30–40 Minuten beim
ersten Mal, danach dauert ein Update etwa 20 Sekunden.

**Ich kann diese Schritte nicht für Sie ausführen** — ich habe keinen Zugang zu
Ihrem DigitalOcean-Konto, und Sie sollten mir auch keine Tokens oder Passwörter
schicken. Alles unten führen Sie selbst aus; die Skripte nehmen Ihnen die Arbeit ab.

---

## Schritt 1 — Droplet anlegen

In der DigitalOcean-Konsole: **Create → Droplets**

| Einstellung | Wert | Warum |
|---|---|---|
| Region | **Frankfurt (FRA1)** | Logfiles bleiben im EWR — genau das, was die Datenschutzerklärung voraussetzt |
| Image | Ubuntu 24.04 LTS | Langzeitunterstützung |
| Größe | Basic, Regular, **1 GB / 1 vCPU** (ca. 6 $/Monat) | Die Seite ist statisch und ein paar hundert Kilobyte groß; kleiner geht nicht, größer bringt nichts |
| Authentifizierung | **SSH-Key**, kein Passwort | Passwörter werden durchprobiert, Keys nicht |
| Hostname | `omegaseed-web` | Wiedererkennung |

Notieren Sie sich die **IPv4-Adresse** des Droplets.

Falls Sie noch keinen SSH-Key haben, auf Ihrem Rechner:

```bash
ssh-keygen -t ed25519 -C "omegaseed-deploy"
cat ~/.ssh/id_ed25519.pub     # diesen Text bei DigitalOcean als SSH-Key hinterlegen
```

---

## Schritt 2 — DNS bei GoDaddy setzen

GoDaddy → **My Products** → bei `omegaseed.io` auf **DNS** → **DNS-Einträge verwalten**.

Vorhandene A-Einträge für `@` und `www` löschen oder anpassen, dann:

| Typ | Name | Wert | TTL |
|---|---|---|---|
| A | `@` | *IPv4 des Droplets* | 600 |
| A | `www` | *IPv4 des Droplets* | 600 |

Falls das Droplet IPv6 hat, zusätzlich:

| Typ | Name | Wert | TTL |
|---|---|---|---|
| AAAA | `@` | *IPv6 des Droplets* | 600 |
| AAAA | `www` | *IPv6 des Droplets* | 600 |

**Löschen Sie die GoDaddy-Parkseite**, falls vorhanden — sonst zeigt die Domain
weiter dorthin. Achten Sie auch auf CNAME-Einträge für `www`; ein CNAME und ein
A-Eintrag für denselben Namen vertragen sich nicht.

Prüfen, bis die richtige Adresse zurückkommt (kann 10–60 Minuten dauern):

```bash
dig +short omegaseed.io
dig +short www.omegaseed.io
```

Erst weitermachen, wenn hier die Droplet-IP steht. Let's Encrypt prüft die
Domain, und ein zu früher Versuch verbraucht Kontingent.

---

## Schritt 3 — Server einrichten (einmalig)

Deploy-Paket auf den Server kopieren und einrichten:

```bash
# auf dem eigenen Rechner, im entpackten Paket
scp -r deploy root@<DROPLET-IP>:/root/
ssh root@<DROPLET-IP>
cd /root/deploy
bash 01-server-setup.sh
```

Das Skript macht:

1. System aktualisieren
2. nginx, certbot, ufw, unattended-upgrades installieren
3. automatische Sicherheitsupdates aktivieren
4. Firewall: nur SSH, HTTP und HTTPS offen
5. Benutzer `deploy` anlegen und Ihren SSH-Key übernehmen
6. Webverzeichnis `/var/www/omegaseed.io` anlegen
7. Let's-Encrypt-Zertifikat für `omegaseed.io` und `www.omegaseed.io` holen
   (fragt vorher, ob der DNS steht)
8. nginx-Konfiguration und Logrotation auf **14 Tage** aktivieren

Die 14 Tage sind kein Zufall: Genau diese Frist nennt Ihre Datenschutzerklärung.
Wenn Sie sie ändern, muss der Text mitgeändert werden.

---

## Schritt 4 — Website hochladen

Auf dem eigenen Rechner, im entpackten Paket (dort, wo `omegaseedphrase-web/` liegt):

```bash
./02-deploy.sh deploy@<DROPLET-IP>
```

Das Skript prüft erst die Prüfsummen **lokal**, überträgt dann per rsync, prüft
die Summen **auf dem Server** erneut und ruft zum Schluss alle Seiten ab. Wenn
irgendwo etwas nicht stimmt, bricht es ab, bevor etwas online geht.

Für jedes weitere Update genügt derselbe eine Befehl.

---

## Schritt 5 — Kontrolle

```bash
# Header prüfen
curl -sI https://omegaseed.io | grep -i 'content-security\|strict-transport\|x-frame'

# Weiterleitungen
curl -sI http://omegaseed.io       | head -1    # erwartet: 301
curl -sI https://www.omegaseed.io  | head -1    # erwartet: 301

# Zertifikat
echo | openssl s_client -connect omegaseed.io:443 -servername omegaseed.io 2>/dev/null \
  | openssl x509 -noout -dates -subject
```

Im Browser durchgehen:

- [ ] Startdialoge erscheinen, Weiter-Button erst nach dem Häkchen aktiv
- [ ] Entwicklerwerkzeuge, Reiter „Netzwerk": **keine** Anfrage an eine fremde Domain
- [ ] Ein Code mit `R` ergibt `Q` auf der Platte
- [ ] Offline-Datei lädt herunter, Prüfsumme stimmt mit `SHA256SUMS.txt`
- [ ] Impressum, Datenschutz, AGB und Changelog erreichbar
- [ ] Die 7 gelben Platzhalter sind ersetzt (siehe README des Web-Pakets)

---

## Zur Content-Security-Policy — Korrektur

In der ersten README stand, die Seite komme ohne `unsafe-inline` aus. **Das war
falsch.** Ich habe die strenge Fassung gegen die echte Seite getestet: Sie
blockiert alle `onclick`-Handler und alle `style`-Attribute. Die Dialoge ließen
sich nicht wegklicken, der Wizard reagierte nicht.

Die mitgelieferte Konfiguration verwendet daher:

```
default-src 'none';
script-src  'self' 'unsafe-inline';
style-src   'self' 'unsafe-inline';
font-src    'self';
img-src     'self' data:;
connect-src 'none';
object-src  'none';
base-uri    'none';
form-action 'none';
frame-ancestors 'none';
```

Das Entscheidende bleibt scharf: **`connect-src 'none'` und `default-src 'none'`
verhindern jede Netzwerkverbindung der Seite.** Selbst wenn Code eingeschleust
würde, könnte er nichts nach außen senden — und genau darauf kommt es bei einer
Seite an, in die Menschen Schlüsselmaterial tippen. `form-action 'none'` schließt
den Weg über ein untergeschobenes Formular.

`unsafe-inline` bei Skripten ist eine echte Abschwächung, aber ohne Angriffsfläche:
Die Seite hat keinen Server, keine Benutzereingaben, die als HTML gerendert werden,
und keine fremden Inhalte. Wenn Sie die Abschwächung dennoch loswerden wollen,
müssten die 19 Inline-Handler auf `addEventListener` umgestellt und die
`style`-Attribute in Klassen überführt werden — das wäre ein Fall für eine
Version 1.1.

Die getestete Fassung ist im mitgelieferten `nginx/omegaseed.io.conf` bereits
eingetragen; die README im Web-Paket korrigiere ich beim nächsten Build.

---

## Wenn etwas klemmt

| Symptom | Ursache und Abhilfe |
|---|---|
| certbot: „Challenge failed" | DNS zeigt noch nicht auf den Server. `dig +short omegaseed.io` prüfen, warten, erneut. |
| 502 oder 404 nach dem Upload | `ssh deploy@IP 'ls -la /var/www/omegaseed.io'` — liegt `index.html` dort? |
| Seite lädt ohne Schriften | Pfade prüfen: `assets/fonts/…` müssen mitgekommen sein. `sha256sum -c SHA256SUMS.txt` auf dem Server. |
| Dialoge reagieren nicht | CSP zu streng. `nginx -T \| grep Content-Security` und mit der Fassung oben vergleichen. |
| „Too many redirects" | Doppelte Weiterleitung, meist ein zusätzlicher Redirect bei GoDaddy. Domain-Forwarding dort deaktivieren. |
| rsync: Permission denied | `ssh root@IP 'chown -R deploy:www-data /var/www/omegaseed.io'` |

---

## Laufender Betrieb

- **Updates der Website:** `./02-deploy.sh deploy@<IP>` — mehr nicht.
- **Zertifikat:** erneuert sich selbst über `certbot.timer`. Prüfen mit
  `systemctl status certbot.timer` und `certbot renew --dry-run`.
- **Systemupdates:** laufen automatisch über `unattended-upgrades`. Etwa einmal
  im Quartal `apt update && apt full-upgrade` und einen Neustart einplanen.
- **Logs:** `/var/log/nginx/omegaseed.access.log`, Aufbewahrung 14 Tage.
- **Backup:** Nicht nötig für die Website selbst — sie liegt vollständig im
  Deploy-Paket. Wichtig ist nur, dass Sie das Paket und die Build-Skripte
  behalten.
