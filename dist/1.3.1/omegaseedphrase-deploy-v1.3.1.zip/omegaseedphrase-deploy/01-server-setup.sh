#!/usr/bin/env bash
# ==============================================================================
#  OmegaSeedphrase — Grundeinrichtung des Droplets
#  EINMALIG auf dem Server ausführen, als root:
#      ssh root@<DROPLET-IP>
#      bash 01-server-setup.sh
# ==============================================================================
set -euo pipefail

DOMAIN="omegaseed.io"
EMAIL="dennis@cundw.io"        # für Let's-Encrypt-Ablaufwarnungen
WEBROOT="/var/www/${DOMAIN}"
DEPLOY_USER="deploy"

say() { printf '\n\033[1;31m▸ %s\033[0m\n' "$*"; }

[[ $EUID -eq 0 ]] || { echo "Bitte als root ausführen."; exit 1; }

say "1/8  System aktualisieren"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get upgrade -y -qq

say "2/8  Pakete installieren"
apt-get install -y -qq nginx certbot python3-certbot-nginx ufw \
                       unattended-upgrades rsync curl

say "3/8  Automatische Sicherheitsupdates"
dpkg-reconfigure -f noninteractive unattended-upgrades

say "4/8  Firewall"
ufw --force reset >/dev/null
ufw default deny incoming
ufw default allow outgoing
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable
ufw status verbose

say "5/8  Deploy-Benutzer anlegen"
if ! id -u "$DEPLOY_USER" >/dev/null 2>&1; then
    adduser --disabled-password --gecos "" "$DEPLOY_USER"
fi
mkdir -p "/home/${DEPLOY_USER}/.ssh"
if [[ -f /root/.ssh/authorized_keys ]]; then
    cp /root/.ssh/authorized_keys "/home/${DEPLOY_USER}/.ssh/authorized_keys"
fi
chown -R "${DEPLOY_USER}:${DEPLOY_USER}" "/home/${DEPLOY_USER}/.ssh"
chmod 700 "/home/${DEPLOY_USER}/.ssh"
chmod 600 "/home/${DEPLOY_USER}/.ssh/authorized_keys" 2>/dev/null || true

say "6/8  Webverzeichnis"
mkdir -p "$WEBROOT" /var/www/certbot
chown -R "${DEPLOY_USER}:www-data" "$WEBROOT"
chmod -R 755 "$WEBROOT"
# Platzhalterseite, damit certbot etwas ausliefern kann
[[ -f "${WEBROOT}/index.html" ]] || echo "<!doctype html><title>omegaseed.io</title>OK" > "${WEBROOT}/index.html"

say "7/8  Zertifikat anfordern"
echo "  Voraussetzung: A-Record von ${DOMAIN} zeigt bereits auf diesen Server."
read -rp "  DNS ist gesetzt und propagiert? [j/N] " ok
if [[ "${ok,,}" == "j" ]]; then
    # temporärer Minimal-vhost, damit certbot die Domain findet
    cat > /etc/nginx/sites-available/default <<EOF
server {
    listen 80 default_server;
    server_name ${DOMAIN} www.${DOMAIN};
    root ${WEBROOT};
    location /.well-known/acme-challenge/ { root /var/www/certbot; }
}
EOF
    nginx -t && systemctl reload nginx
    certbot certonly --webroot -w /var/www/certbot \
        -d "${DOMAIN}" -d "www.${DOMAIN}" \
        --email "${EMAIL}" --agree-tos --no-eff-email --non-interactive
else
    echo "  Übersprungen. Nach dem DNS-Eintrag ausführen:"
    echo "    certbot certonly --webroot -w /var/www/certbot -d ${DOMAIN} -d www.${DOMAIN} --email ${EMAIL} --agree-tos"
    exit 0
fi

say "8/8  Konfiguration aktivieren"
cp nginx/${DOMAIN}.conf /etc/nginx/sites-available/${DOMAIN}.conf
ln -sf ../sites-available/${DOMAIN}.conf /etc/nginx/sites-enabled/${DOMAIN}.conf
rm -f /etc/nginx/sites-enabled/default
cp system/logrotate-omegaseed /etc/logrotate.d/omegaseed
logrotate -d /etc/logrotate.d/omegaseed >/dev/null && echo "  logrotate: 14 Tage aktiv"
nginx -t && systemctl reload nginx
systemctl enable --now certbot.timer

say "Fertig."
echo "  Website:   https://${DOMAIN}"
echo "  Webroot:   ${WEBROOT}"
echo "  Nächster Schritt: 02-deploy.sh vom eigenen Rechner ausführen."
