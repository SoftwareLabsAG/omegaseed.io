#!/usr/bin/env bash
# ==============================================================================
#  OmegaSeedphrase — Dateien auf den Server bringen
#  Auf dem EIGENEN Rechner ausführen, im entpackten Paketverzeichnis:
#      ./02-deploy.sh <DROPLET-IP>
#  oder mit gesetztem SERVER:
#      SERVER=deploy@203.0.113.10 ./02-deploy.sh
# ==============================================================================
set -euo pipefail

DOMAIN="omegaseed.io"
WEBROOT="/var/www/${DOMAIN}"
SERVER="${SERVER:-${1:-}}"
SRC="omegaseedphrase-web"

say()  { printf '\n\033[1;31m▸ %s\033[0m\n' "$*"; }
fail() { printf '\033[1;31m✗ %s\033[0m\n' "$*"; exit 1; }

[[ -n "$SERVER" ]] || fail "Server fehlt.  Aufruf: ./02-deploy.sh deploy@<IP>"
[[ "$SERVER" == *@* ]] || SERVER="deploy@${SERVER}"
[[ -d "$SRC" ]] || fail "Verzeichnis '$SRC' nicht gefunden. Bitte im entpackten Paket ausführen."

say "1/5  Paket prüfen"
( cd "$SRC" && sha256sum -c SHA256SUMS.txt --quiet ) \
  && echo "  Alle Prüfsummen stimmen." \
  || fail "Prüfsummen stimmen nicht — Paket nicht hochladen."

VERSION=$(grep -o '"version"[^,]*' "$SRC/version.json" | cut -d'"' -f4)
echo "  Version: ${VERSION}"

say "2/5  Verbindung testen"
ssh -o ConnectTimeout=10 "$SERVER" "echo '  Verbunden mit' \$(hostname)" || fail "SSH schlug fehl."

say "3/5  Dateien übertragen"
# --delete räumt alte Dateien weg; SHA256SUMS und README bleiben bewusst mit drin,
# damit die Prüfsummen auch auf dem Server nachvollziehbar sind.
rsync -az --delete --human-readable --info=stats1 \
      --chmod=D755,F644 \
      "$SRC"/ "$SERVER:${WEBROOT}/"

say "4/5  Auf dem Server gegenprüfen"
ssh "$SERVER" "cd ${WEBROOT} && sha256sum -c SHA256SUMS.txt --quiet && echo '  Prüfsummen auf dem Server stimmen.'" \
  || fail "Übertragung fehlerhaft."

say "5/5  Erreichbarkeit prüfen"
for path in / /impressum.html /datenschutz.html /agb.html /changelog.html /version.json \
            /download/omegaseedphrase-offline.html \
            /en/ /en/legal-notice.html /en/privacy.html /en/terms.html /en/changelog.html \
            /download/omegaseedphrase-offline-en.html; do
    code=$(curl -s -o /dev/null -w '%{http_code}' "https://${DOMAIN}${path}" || echo 000)
    printf '  %-45s %s\n' "$path" "$code"
done

echo
echo "  Sicherheits-Header:"
curl -sI "https://${DOMAIN}/" | grep -iE 'content-security|strict-transport|x-content-type|x-frame|referrer|permissions' \
  | sed 's/^/    /' || echo "    (keine gefunden — nginx-Konfiguration prüfen)"

echo
printf '\033[1;32m✓ Version %s ist online: https://%s\033[0m\n' "$VERSION" "$DOMAIN"
